'use strict';
const el = id => document.getElementById(id);
const ORDER = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
const SUIT_ORDER = ['hearts','diamonds','clubs','spades'];
const BOUNCE_HEALTH = 0.2;
const BOUNCE_DAMAGE = 30;
const DAMAGE_MULTIPLIER = 1.15;
const ATTACK_ORDER = ['quick','heavy','special'];
let cards = {}, selection = [null,null], fighters = [], moves = [null,null];
let pickerPlayer = 0, round = 1, finished = false, animating = false, matchId = 0;
let scanStream=null, scanIsOpen=false, scanBusy=false, scanSession=0, scanPlayer=0, scanCanvas=null;
const safe = text => String(text).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function allCards(){return Object.values(cards).sort((a,b)=>SUIT_ORDER.indexOf(a.suit)-SUIT_ORDER.indexOf(b.suit)||ORDER.indexOf(a.rank)-ORDER.indexOf(b.rank));}
function hpBar(current,max){return Math.max(0,100*current/max)}
async function init(){const res=await fetch('/data/cards');if(!res.ok)throw new Error('Card data unavailable');cards=await res.json();bind();resizeStage();addEventListener('resize',resizeStage);}
function resizeStage(){const scale=Math.min(window.innerWidth/680,window.innerHeight/400,3);el('stage')?.style.setProperty('transform',`translate(-50%, -50%) scale(${Math.max(.42,scale)})`);}
function bind(){

 el('scan0').onclick=()=>openScanner(0);el('scan1').onclick=()=>openScanner(1);
 el('closeScan').onclick=closeScanner;el('captureScan').onclick=scanOnce;
 el('cameraDevice').onchange=()=>startScannerCamera(el('cameraDevice').value);
 el('manualInstead').onclick=()=>{const target=scanPlayer;closeScanner();openPicker(target)};
 el('closePicker').onclick=closePicker;
 el('picker').addEventListener('click',e=>{if(e.target===el('picker'))closePicker()});
 el('suitFilter').onchange=renderPicker;el('cardSearch').oninput=renderPicker;
 el('start').onclick=startBattle;el('restart').onclick=reset;el('playAgain').onclick=reset;
 el('nextRound').onclick=()=>{round++;moves=[null,null];el('roundDone').classList.add('hidden');el('choice').classList.remove('hidden');renderFighters();renderChoices();};
 addEventListener('keydown',e=>{if(e.key==='Escape'){closePicker();closeScanner()}});
}
function openPicker(player){pickerPlayer=player;el('pickerTitle').textContent=`PLAYER ${player+1} CHOOSE A CARD`;el('picker').classList.remove('hidden');el('cardSearch').value='';el('suitFilter').value='all';renderPicker();}
function closePicker(){el('picker').classList.add('hidden');}
function renderPicker(){
 const suit=el('suitFilter').value, q=el('cardSearch').value.toLowerCase().trim();
 el('cardGrid').replaceChildren();
 for(const card of allCards()){
  if(suit!=='all'&&card.suit!==suit)continue;
  if(q&&!`${card.symbol} ${card.name} ${card.rank} ${card.suit}`.toLowerCase().includes(q))continue;
  const b=document.createElement('button');b.className='picker-card';
  if(selection[1-pickerPlayer]===card.id){b.disabled=true;b.title='Other player already has this physical card'}
  b.innerHTML=`<img src="${card.image}" alt=""><strong>${safe(card.symbol)}</strong><small>${safe(card.name)}</small>`;
  b.onclick=()=>{register(pickerPlayer,card.id);closePicker()};el('cardGrid').appendChild(b);
 }
 if(!el('cardGrid').children.length)el('cardGrid').innerHTML='<p class="no-matches">NO MATCHING CARDS</p>';
}
function register(player,id){if(!cards[id]||selection[1-player]===id)return;selection[player]=id;const c=cards[id];
 el('slot'+player).innerHTML=`<div class="loaded"><img src="${c.image}" alt="${safe(c.name)}"><div class="loaded-copy"><strong>${safe(c.name)}</strong><small>${safe(c.role)}</small></div></div>`;

 el('start').disabled=!selection.every(Boolean);
}
function makeFighter(id){const c=cards[id];return {...c,currentHp:c.hp,shield:0,speedBuff:0,ultimateUsed:false}}
function startBattle(){if(!selection.every(Boolean))return;matchId++;closeScanner();fighters=selection.map(makeFighter);moves=[null,null];round=1;finished=false;
 el('setup').classList.add('hidden');el('battle').classList.remove('hidden');
 ['roundDone','result'].forEach(id=>el(id).classList.add('hidden'));el('choice').classList.remove('hidden');
 el('log').textContent='Choose your attacks.';
 renderFighters();renderChoices();
}
function renderFighters(){
 fighters.forEach((f,i)=>{
  el('fight'+i).innerHTML=`<div class="battle-stat-top"><span>PLAYER ${i+1}</span><b>${safe(f.name)}</b></div><div class="statline"><span>Health</span><span>${f.currentHp} / ${f.hp}</span></div><div class="track"><div class="hpbar" style="width:${hpBar(f.currentHp,f.hp)}%"></div></div>`;
  const holder=el('sprite'+i);holder.replaceChildren();const img=document.createElement('img');img.src=f.sprite;img.alt=f.name;img.onerror=()=>{img.src=f.image;img.classList.add('fallback-art')};holder.appendChild(img);
 });
}
function expectedDamage(attacker,defender,kind){
 const base={quick:40,heavy:46,special:39};
 const strongest=ATTACK_ORDER[(round-1)%3];
 const power=base[kind]+(kind===strongest?28:0);
 return Math.max(1,Math.round(DAMAGE_MULTIPLIER*power*attacker.attack/(attacker.attack+defender.defense)));
}
const attackNames=[
 {quick:'Blade Rush',heavy:'Meteor Storm',special:'Skyfall Barrage',ultimate:'Bounce Back Attack'},
 {quick:'Star Projectiles',heavy:'Tidal Wave',special:'Gravity Vortex',ultimate:'Bounce Back Attack'}
];
function attackName(player,kind){
 if(kind==='ultimate')return 'Bounce Back Attack';
 return cards[selection[player]].name.split(' ')[0]+' '+attackNames[player][kind];
}
function renderChoices(){
 for(let player=0;player<2;player++){
  const holder=el('moves'+player),fighter=fighters[player],enemy=fighters[1-player];
  holder.replaceChildren();
  for(const type of ['quick','heavy','special','ultimate']){
   const button=document.createElement('button');
   button.className='move'+(moves[player]===type?' selected':'')+(type===ATTACK_ORDER[(round-1)%3]?' boosted':'');
   const unavailable=type==='ultimate'&&(fighter.currentHp>fighter.hp*BOUNCE_HEALTH||fighter.ultimateUsed);
   button.disabled=unavailable||moves[player]!==null;
   const label=attackName(player,type);
   button.innerHTML=`<strong>${safe(label)}</strong><small>${unavailable?'Unlocks at 20% health':type==='ultimate'?'Damage '+BOUNCE_DAMAGE:'Damage '+expectedDamage(fighter,enemy,type)}</small>`;
   button.onclick=()=>pickMove(player,type);
   holder.appendChild(button);
  }
 }
}
function pickMove(player,type){
 if(finished||animating||moves[player]!==null)return;
 moves[player]=type;
 renderChoices();
 el('log').textContent=moves.every(Boolean)?'Both moves selected.':'Player '+(player+1)+' is ready.';
 if(moves.every(Boolean))resolveRound();
}
function takeDamage(attacker,defender,move,events){
 const speedGap=defender.speed+defender.speedBuff-attacker.speed-attacker.speedBuff;
 const dodgeChance=Math.min(.35,Math.max(.04,.1+speedGap*.007));
 if(move!=='ultimate'&&Math.random()<dodgeChance){events.push(defender.name+' dodged!');return {damage:0,dodged:true,critical:false};}
 let damage=move==='ultimate'?BOUNCE_DAMAGE:expectedDamage(attacker,defender,move);
 const critical=move!=='ultimate'&&Math.random()<attacker.critChance+(move==='special'&&attacker.suit==='diamonds'?.22:0);
 if(critical)damage=Math.round(damage*1.5);
 if(move!=='ultimate'&&defender.shield){const blocked=Math.min(defender.shield,damage);defender.shield-=blocked;damage-=blocked;}
 damage=Math.min(defender.currentHp,damage);
 defender.currentHp-=damage;
 if(move==='special'||move==='ultimate'){
  const boost=move==='ultimate'?1.5:1;
  if(attacker.suit==='hearts')attacker.currentHp=Math.min(attacker.hp,attacker.currentHp+Math.round(10*boost));
  if(attacker.suit==='clubs')attacker.shield=Math.min(32,attacker.shield+Math.round(15*boost));
  if(attacker.suit==='spades')attacker.speedBuff=Math.min(28,attacker.speedBuff+Math.round(9*boost));
 }
 events.push(move==='ultimate'?attacker.name+' unleashed Bounce Back Attack!':critical?'Critical hit! '+damage+' damage.':attacker.name+' dealt '+damage+' damage.');
 return {damage,dodged:false,critical};
}
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const SVG_NS='http://www.w3.org/2000/svg';
function draw(parent,tag,attrs={}){
 const node=document.createElementNS(SVG_NS,tag);
 for(const [name,value] of Object.entries(attrs))node.setAttribute(name,value);
 parent.appendChild(node);
 return node;
}
function pixelateLines(svg){
 for(const path of Array.from(svg.querySelectorAll('path'))){
  const length=path.getTotalLength();
  if(!length)continue;
  const width=Number(path.getAttribute('stroke-width')||3);
  const size=width>=20?7:width>=10?5:3;
  const stripes=Math.min(7,Math.max(1,Math.round(width/size)));
  const count=Math.min(120,Math.ceil(length/(size*.85)));
  const group=draw(svg,'g',{class:'pixel-chain '+path.getAttribute('class')});
  const delay=Number.parseFloat(path.style.animationDelay)||0;
  const fill=path.getAttribute('stroke')||'#fff';
  for(let i=0;i<=count;i++){
   const point=path.getPointAtLength(length*i/count);
   const next=path.getPointAtLength(Math.min(length,length*(i+1)/count));
   const dx=next.x-point.x,dy=next.y-point.y,mag=Math.hypot(dx,dy)||1;
   for(let j=0;j<stripes;j++){
    const offset=(j-(stripes-1)/2)*size;
    const x=Math.round((point.x-dy/mag*offset)/size)*size;
    const y=Math.round((point.y+dx/mag*offset)/size)*size;
    const pixel=draw(group,'rect',{x,y,width:size,height:size,fill,class:'pixel-bit'});
    pixel.style.animationDelay=(delay+Math.round(700*i/count))+'ms';
   }
  }
  group.style.animationDelay=path.style.animationDelay;
  path.remove();
 }
}
function effectType(player,move){
 const styles=[
  {quick:'swipe',heavy:'meteor',special:'skybeam',ultimate:'ultimate'},
  {quick:'projectile',heavy:'wave',special:'vortex',ultimate:'nova'}
 ];
 return styles[player][move]||'swipe';
}
function effect(attacker,target,move,result){
 const layer=el('effects');layer.replaceChildren();
 const svg=draw(layer,'svg',{viewBox:'0 0 604 195',preserveAspectRatio:'none',class:'combat-fx'});
 const defs=draw(svg,'defs');
 const glow=draw(defs,'radialGradient',{id:'impactGlow'});
 draw(glow,'stop',{offset:'0%', 'stop-color':'#ffffff','stop-opacity':'.9'});
 draw(glow,'stop',{offset:'50%', 'stop-color':'#96dffb','stop-opacity':'.55'});
 draw(glow,'stop',{offset:'100%', 'stop-color':'#96dffb','stop-opacity':'0'});
 const x=target===0?155:450,from=target===0?450:155;
 const player=1-target,kind=effectType(player,move);
 const line=(attrs,klass,delay=0)=>{const n=draw(svg,'path',attrs);n.setAttribute('class',klass);n.style.animationDelay=delay+'ms';return n;};
 const dot=(attrs,klass,delay=0)=>{const small=attrs.r<=12;const size=attrs.r*2;const props=small?{...attrs,x:attrs.cx-attrs.r,y:attrs.cy-attrs.r,width:size,height:size}:{...attrs};if(small){delete props.cx;delete props.cy;delete props.r;}const n=draw(svg,small?'rect':'circle',props);n.setAttribute('class',klass);n.style.animationDelay=delay+'ms';return n;};
 if(kind==='rain'){
  for(let n=0;n<35;n++){
   const px=x-96+(n*43)%196,py=-30-(n*29)%125;
   line({d:`M ${px} ${py} l -12 31`,stroke:n%4?'#69b8df':'#d6f6ff','stroke-width':n%5?2:3,'stroke-linecap':'round'},'rain-drop',n*41);
  }
  for(let n=0;n<8;n++)line({d:`M ${x-78+n*22} 144 q 10 -11 20 0`,stroke:'#8eddf6','stroke-width':2,fill:'none'},'rain-ripple',n*100);
 }else if(kind==='quake'){
  for(let n=0;n<6;n++){
   const xx=x-110+n*40;
   line({d:`M ${xx} 164 l ${-8+n%3*8} 12 l ${10-n%4*6} 12`,stroke:'#4c4538','stroke-width':3,fill:'none','stroke-linejoin':'round'},'quake-crack',n*100);
   dot({cx:xx,cy:174,r:4+(n%3)*2,fill:n%2?'#9d7f5a':'#d7c3a0'},'quake-rock',n*115);
  }
 }else if(kind==='projectile'){
  for(let n=0;n<6;n++){
   const yy=54+n*19,start=from+(target===0?-n*8:n*8);
   const end=x+(n%3-1)*17;
   const shot=dot({cx:start,cy:yy,r:5+n%2,fill:n%2?'#f9cd87':'#ffe8ba'},'flying-orb',n*180);
   shot.style.setProperty('--dx',(end-start)+'px');
   shot.style.setProperty('--dy',(90+n%4*9-yy)+'px');
   line({d:`M ${start} ${yy} Q ${(start+end)/2} ${yy-34} ${end} ${95+n%3*8}`,fill:'none',stroke:'#bcb3fa','stroke-width':2,'stroke-dasharray':'5 6'},'orb-trail',n*180);
  }
 }else if(kind==='wave'){
  const dir=target===0?-1:1;
  for(let n=0;n<5;n++){
   const wave=draw(svg,'path',{d:`M ${from} ${147+n*3} Q ${(from+x)/2} ${115-n*6} ${x} ${148+n*2}`,fill:'none',stroke:n%2?'#c4f4ff':'#5db8dc','stroke-width':10-n,'stroke-linecap':'round',class:'water-wave'});
   wave.style.animationDelay=n*180+'ms';
   wave.style.setProperty('--wave-distance',(dir*60)+'px');
  }
  for(let n=0;n<12;n++)dot({cx:x-50+n*9,cy:145+(n%3)*5,r:2+n%2,fill:'#e4f9ff'},'impact-spark',n*80+550);
 }else if(kind==='vortex'){
  for(let n=0;n<7;n++){
   const r=22+n*8;
   const ring=draw(svg,'ellipse',{cx:x,cy:104,rx:r,ry:Math.max(9,r*.55),fill:'none',stroke:n%2?'#e3bff7':'#9a85df','stroke-width':3,class:'vortex-ring'});
   ring.style.animationDelay=n*140+'ms';
  }
  for(let n=0;n<12;n++){
   const a=n*2.399;
   dot({cx:x+Math.cos(a)*55,cy:103+Math.sin(a)*32,r:2+n%3,fill:'#fff4d6'},'impact-spark',n*95+350);
  }
 }else if(kind==='nova'){
  dot({cx:x,cy:103,r:107,fill:'url(#impactGlow)'},'ultimate-glow');
  for(let n=0;n<8;n++){
   const r=18+n*11;
   const ring=draw(svg,'ellipse',{cx:x,cy:103,rx:r,ry:r*.65,fill:'none',stroke:n%2?'#e4f7ff':'#9d8af1','stroke-width':8-n*.6,class:'nova-ring'});
   ring.style.animationDelay=n*150+'ms';
  }
  for(let n=0;n<32;n++){
   const a=n*Math.PI*2/32,dist=35+(n%4)*16;
   const shard=draw(svg,'rect',{x:x-3,y:100,width:5,height:5,fill:n%2?'#b4adf9':'#e4faff',class:'glass-shard'});
   shard.style.setProperty('--dx',Math.cos(a)*dist+'px');
   shard.style.setProperty('--dy',Math.sin(a)*dist+'px');
   shard.style.animationDelay=(350+n*36)+'ms';
  }
 }else if(kind==='beam'||kind==='ultimate'){
  const start=from+(x>from?18:-18),end=x+(x>from?-9:9),y=100;
  if(kind==='ultimate'){
   dot({cx:x,cy:y,r:108,fill:'url(#impactGlow)'},'ultimate-glow');
   for(let n=0;n<24;n++){
    const a=n*2.399,dx=Math.cos(a)*(32+n%5*17),dy=Math.sin(a)*(25+n%4*11);
    const shard=draw(svg,'polygon',{points:`${x-4},${y-5} ${x+5},${y-2} ${x},${y+7}`,fill:n%2?'#dbf8ff':'#72d5fa',class:'glass-shard'});
    shard.style.setProperty('--dx',dx+'px');shard.style.setProperty('--dy',dy+'px');
    shard.style.animationDelay=(500+n*24)+'ms';
   }
  }
  const thickness=kind==='ultimate'?29:13;
  const core=line({d:`M ${start} ${y} Q ${(start+end)/2} ${y-5} ${end} ${y}`,fill:'none',stroke:kind==='ultimate'?'#63d4ff':'#60bfea','stroke-width':thickness+17,'stroke-linecap':'round'},kind==='ultimate'?'ultimate-beam-aura':'energy-beam');
  core.style.transformOrigin=start+'px '+y+'px';
  const inner=line({d:`M ${start} ${y} L ${end} ${y}`,fill:'none',stroke:'#f5ffff','stroke-width':thickness,'stroke-linecap':'round'},kind==='ultimate'?'ultimate-beam':'energy-beam',80);
  inner.style.transformOrigin=start+'px '+y+'px';
  for(let n=0;n<7;n++)dot({cx:end+(n%3-1)*14,cy:y+(n%4-2)*10,r:2+n%3,fill:'#e8fcff'},'impact-spark',350+n*70);
 }else if(kind==='skybeam'||kind==='ice'){
  for(let n=0;n<(kind==='skybeam'?7:14);n++){
   const xx=x-90+n*(kind==='skybeam'?31:14);
   if(kind==='skybeam'){
    line({d:`M ${xx-12} -18 L ${xx+5} 151`,fill:'none',stroke:'#70c6fa','stroke-width':12,'stroke-linecap':'round'},'sky-beam',n*130);
    line({d:`M ${xx-12} -18 L ${xx+5} 151`,fill:'none',stroke:'#e8ffff','stroke-width':5,'stroke-linecap':'round'},'sky-beam',n*130+70);
   }else{
    const flake=draw(svg,'polygon',{points:`${xx},-16 ${xx+7},-2 ${xx},12 ${xx-7},-2`,fill:n%2?'#dffaff':'#8bcfee',stroke:'#5b9ac7','stroke-width':1,class:'ice-fall'});
    flake.style.animationDelay=n*92+'ms';
   }
  }
 }else if(kind==='meteor'){
  for(let n=0;n<11;n++){
   const xx=x+110-n*22;
   line({d:`M ${xx+70} -42 l -40 55`,stroke:'#eaa66b','stroke-width':6+n%3,'stroke-linecap':'round'},'meteor-trail',n*96);
   dot({cx:xx+45,cy:-25,r:7+n%3,fill:n%2?'#ffd09b':'#f38e77'},'meteor-core',n*96);
  }
 }else if(kind==='lightning'){
  for(let n=0;n<5;n++){
   const xx=x-66+n*32;
   line({d:`M ${xx-10} -4 l 18 48 -17 12 21 45 -13 23`,fill:'none',stroke:n%2?'#e9f8ff':'#a7ddfc','stroke-width':5,'stroke-linejoin':'round','stroke-linecap':'round'},'lightning-bolt',n*220);
  }
 }else{
  for(let n=0;n<3;n++){
   line({d:`M ${x-56+n*13} ${88+n*14} Q ${x+12} ${30+n*18} ${x+61} ${95+n*9}`,fill:'none',stroke:n===1?'#fff9da':'#e6a8be','stroke-width':n===1?6:3,'stroke-linecap':'round'},'swipe-arc',n*95);
  }
 }
 if(!['ultimate','nova'].includes(kind))dot({cx:x,cy:103,r:58,fill:'url(#impactGlow)'},'impact-flash',450);
 for(let n=0;n<12;n++){
  const px=x+(n%4-2)*13,py=82+Math.floor(n/4)*17;
  const spark=draw(svg,'rect',{x:px,y:py,width:3+n%2*2,height:3+n%2*2,fill:n%2?'#fff8cb':'#d5ecff',class:'impact-spark'});
  spark.style.animationDelay=(420+n*55)+'ms';
 }
 pixelateLines(svg);
 const number=document.createElement('span');number.className='floating-damage';number.textContent=result.dodged?'DODGE':'−'+result.damage;number.style.left=(x/604*100)+'%';layer.appendChild(number);
 const defender=el('sprite'+target),source=el('sprite'+(1-target));
 defender.classList.remove('hit','dodge');source.classList.remove('attack-left','attack-right');
 void defender.offsetWidth;
 defender.classList.add(result.dodged?'dodge':'hit');
 if(kind==='swipe')source.classList.add(target===0?'attack-left':'attack-right');
 if(kind==='quake')document.querySelector('.arena').classList.add('quake-active');
 if(kind==='ultimate'||kind==='nova')document.querySelector('.arena').classList.add('ultimate-active');
 return kind==='ultimate'||kind==='nova'?2700:['meteor','wave','vortex'].includes(kind)?2250:1950;
}
async function resolveRound(){
 animating=true;
 const currentMatch=matchId,choices=moves.slice(),log=[];
 const priority=(f,type)=>type==='ultimate'?99:f.moves[type].priority;
 const p0=priority(fighters[0],choices[0]),p1=priority(fighters[1],choices[1]);
 const s0=fighters[0].speed+fighters[0].speedBuff,s1=fighters[1].speed+fighters[1].speedBuff;
 const first=p0!==p1?(p0>p1?0:1):s0!==s1?(s0>s1?0:1):(Math.random()<.5?0:1);
 for(const i of [first,1-first]){
  if(currentMatch!==matchId)return;
  const attacker=fighters[i],defender=fighters[1-i],move=choices[i];
  if(attacker.currentHp<=0||el('battle').classList.contains('hidden'))continue;
  if(move==='ultimate'){
   if(attacker.ultimateUsed||attacker.currentHp>attacker.hp*BOUNCE_HEALTH)continue;
   attacker.ultimateUsed=true;
  }
  const result=takeDamage(attacker,defender,move,log);
  el('log').textContent=attackName(i,move).toUpperCase()+'!';
  const duration=effect(attacker,1-i,move,result);
  await pause(duration);
  if(currentMatch!==matchId)return;
  el('log').textContent=log.at(-1);
  renderFighters();
  el('effects').replaceChildren();
  document.querySelector('.arena').classList.remove('quake-active','ultimate-active');
  for(let n=0;n<2;n++)el('sprite'+n).classList.remove('hit','dodge','attack-left','attack-right');
  await pause(340);
  if(defender.currentHp<=0)break;
 }
 if(currentMatch!==matchId)return;
 if(fighters.some(f=>f.currentHp<=0)){
  finished=true;el('result').classList.remove('hidden');
  const winner=fighters.find(f=>f.currentHp>0);
  el('resultTitle').textContent=winner?winner.name.toUpperCase()+' WINS!':'DRAW!';
  el('resultSubtitle').textContent='Play another match?';
 }else{
  el('roundDone').classList.remove('hidden');el('choice').classList.add('hidden');
 }
 animating=false;
}
function reset(){matchId++;animating=false;el('effects').replaceChildren();document.querySelector('.arena').classList.remove('quake-active','ultimate-active');closeScanner();selection=[null,null];fighters=[];moves=[null,null];round=1;finished=false;closePicker();el('setup').classList.remove('hidden');el('battle').classList.add('hidden');
 for(const i of [0,1])el('slot'+i).innerHTML=`<div class="empty"><span class="card-silhouette"></span><strong>PLAYER ${i+1}</strong></div>`;
 el('start').disabled=true;
}

async function openScanner(player=0){
 closeScanner();closePicker();scanIsOpen=true;scanPlayer=player;
 scanSession++;
 el('scanTitle').textContent='CARD SCANNER PLAYER '+(player+1);
 el('scanStatus').textContent='Position the card and click SCAN NOW';
 el('extractedBox').classList.add('hidden');
 el('captureScan').disabled=true;
 el('scanModal').classList.remove('hidden');
 scanCanvas=document.createElement('canvas');
 await startScannerCamera();
}
function closeScanner(){
 scanIsOpen=false;scanSession++;
 if(scanStream){scanStream.getTracks().forEach(track=>track.stop());scanStream=null;}
 const video=el('scanVideo');if(video)video.srcObject=null;
 el('scanModal')?.classList.add('hidden');
 el('captureScan').disabled=true;
}
async function startScannerCamera(deviceId=''){
 if(!scanIsOpen)return;
 const session=++scanSession;
 if(scanStream){scanStream.getTracks().forEach(t=>t.stop());scanStream=null;}
 el('captureScan').disabled=true;
 const wanted=deviceId||el('cameraDevice').value;
 try{
  const constraints={audio:false,video:wanted?{deviceId:{exact:wanted},width:{ideal:1280},height:{ideal:720}}:{width:{ideal:1280},height:{ideal:720}}};
  const media=await navigator.mediaDevices.getUserMedia(constraints);
  if(!scanIsOpen||session!==scanSession){media.getTracks().forEach(t=>t.stop());return;}
  scanStream=media;
  const video=el('scanVideo');video.srcObject=media;await video.play();
  if(!scanIsOpen||session!==scanSession)return;
  await listCameras(media.getVideoTracks()[0]?.getSettings()?.deviceId||wanted);
  el('scanStatus').textContent='Position the card and click SCAN NOW';
  el('captureScan').disabled=false;
 }catch(err){
  if(session===scanSession&&scanIsOpen)el('scanStatus').textContent='Camera unavailable — select a camera or use manual pick';
  console.error('Camera:',err);
 }
}
async function listCameras(chosen){
 try{
  const devices=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='videoinput');
  const select=el('cameraDevice');select.replaceChildren();
  for(const d of devices){const o=document.createElement('option');o.value=d.deviceId;o.textContent=d.label||'Camera';select.appendChild(o);}
  const prefer=devices.find(d=>/camo|iphone|reincubate/i.test(d.label));
  const current=devices.find(d=>d.deviceId===chosen);
  select.value=current?.deviceId||prefer?.deviceId||devices[0]?.deviceId||'';
 }catch(err){console.warn('Camera list unavailable',err);}
}
function captureFrame(){
 const video=el('scanVideo');
 if(!video.videoWidth||!video.videoHeight)return null;
 const vw=video.videoWidth,vh=video.videoHeight;
 const scale=Math.min(1,1280/Math.max(vw,vh));
 const canvas=scanCanvas;
 canvas.width=Math.max(1,Math.round(vw*scale));
 canvas.height=Math.max(1,Math.round(vh*scale));
 canvas.getContext('2d',{alpha:false}).drawImage(video,0,0,canvas.width,canvas.height);
 return canvas;
}
async function scanOnce(){
 if(!scanIsOpen||scanBusy||!scanStream)return;
 const session=scanSession,player=scanPlayer;
 scanBusy=true;
 el('captureScan').disabled=true;
 el('scanStatus').textContent='Finding the complete card and matching all 52...';
 el('extractedBox').classList.add('hidden');
 try{
  const canvas=captureFrame();
  if(!canvas)throw new Error('Camera is not ready');
  const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.86));
  if(!blob)throw new Error('Could not capture the photo');
  const response=await fetch('/api/scan',{method:'POST',headers:{'Content-Type':'image/jpeg'},body:blob});
  if(!response.ok)throw new Error('Scan failed ('+response.status+')');
  const result=await response.json();
  if(!scanIsOpen||session!==scanSession)return;
  if(result.preview){el('extractedCard').src=result.preview;el('extractedBox').classList.remove('hidden');}
  const id=result.ok?result.cardId:null;
  if(id&&cards[id]&&id!==selection[1-player]){
   register(player,id);
   el('scanStatus').textContent='Scan successful: '+(result.label||cards[id].symbol);
   setTimeout(()=>{if(scanIsOpen&&session===scanSession)closeScanner()},900);
  }else if(id !== null && id === selection[1-player]){
   el('scanStatus').textContent='That card belongs to the other player. Try another.';
  }else{
   el('scanStatus').textContent=result.message||'Card detection failed. Check all four edges and try again.';
  }
 }catch(err){
  if(scanIsOpen&&session===scanSession)el('scanStatus').textContent=err.message+' — try again.';
  console.warn('Single scan:',err);
 }finally{
  scanBusy=false;
  if(scanIsOpen&&session===scanSession&&el('scanStatus').textContent.indexOf('Scan successful')!==0)
   el('captureScan').disabled=false;
 }
}
init().catch(err=>{console.error('Could not load cards',err);alert('Could not load card data. Restart the server.');});
