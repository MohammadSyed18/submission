from pathlib import Path
from functools import lru_cache
import base64
import cv2
import numpy as np
ROOT = Path(__file__).resolve().parent
SUITS = {'clubs':'♣','diamonds':'♦','hearts':'♥','spades':'♠'}
W,H = 240,336
def _order(pts):
    p=np.asarray(pts,dtype=np.float32).reshape(4,2)
    s=p.sum(axis=1); d=np.diff(p,axis=1).ravel()
    return np.array([p[np.argmin(s)],p[np.argmin(d)],p[np.argmax(s)],p[np.argmax(d)]],np.float32)
def _warp(image, quad):
    p=_order(quad)
    a=(np.linalg.norm(p[0]-p[1])+np.linalg.norm(p[2]-p[3]))/2
    b=(np.linalg.norm(p[0]-p[3])+np.linalg.norm(p[1]-p[2]))/2
    if a>b: 
        p=np.roll(p,1,axis=0)
    target=np.float32([[0,0],[W-1,0],[W-1,H-1],[0,H-1]])
    return cv2.warpPerspective(image,cv2.getPerspectiveTransform(p,target),(W,H),flags=cv2.INTER_LINEAR)
def _quads(image):
    h,w=image.shape[:2]
    factor=min(1.0,1200/max(w,h))
    reduced=cv2.resize(image,None,fx=factor,fy=factor,interpolation=cv2.INTER_AREA) if factor<1 else image
    hh,ww=reduced.shape[:2]
    gray=cv2.cvtColor(reduced,cv2.COLOR_BGR2GRAY)
    blurred=cv2.GaussianBlur(gray,(5,5),0)
    edges=cv2.Canny(blurred,35,110)
    edges=cv2.morphologyEx(edges,cv2.MORPH_CLOSE,np.ones((7,7),np.uint8))
    otsu=cv2.threshold(gray,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]
    adap=cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,71,-8)
    lab=cv2.cvtColor(reduced,cv2.COLOR_BGR2LAB).astype(np.float32)
    bh=max(10,hh//16); bw=max(10,ww//16)
    border=np.concatenate([lab[:bh].reshape(-1,3),lab[-bh:].reshape(-1,3),lab[:,:bw].reshape(-1,3),lab[:,-bw:].reshape(-1,3)])
    background=np.median(border,axis=0)
    difference=np.sqrt(np.square(lab-background).sum(axis=2))
    threshold=max(14.0,float(np.percentile(np.sqrt(np.square(border-background).sum(axis=1)),88))+10.0)
    mask_bg=(difference>threshold).astype(np.uint8)*255
    mask_bg=cv2.morphologyEx(mask_bg,cv2.MORPH_CLOSE,np.ones((11,11),np.uint8))
    masks=[mask_bg,edges]+[cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((9,9),np.uint8)) for m in [otsu,adap]]
    result=[]
    for mask in masks:
        contours,_=cv2.findContours(mask,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
        for c in sorted(contours,key=cv2.contourArea,reverse=True)[:50]:
            area=cv2.contourArea(c)
            if not (.055<area/(ww*hh)<.90):continue
            peri=cv2.arcLength(c,True)
            for epsilon in [.020,.040,.070]:
                approximation=cv2.approxPolyDP(c,epsilon*peri,True)
                if len(approximation)!=4 or not cv2.isContourConvex(approximation):continue
                p=_order(approximation.reshape(4,2))/factor
                cw=(np.linalg.norm(p[0]-p[1])+np.linalg.norm(p[2]-p[3]))/2
                ch=(np.linalg.norm(p[0]-p[3])+np.linalg.norm(p[1]-p[2]))/2
                aspect=min(cw,ch)/max(cw,ch)
                if not (.52<aspect<.87):continue
                if any(np.linalg.norm(p-old)<18 for old in result):continue
                result.append(p)
                break
            if len(result)>=9:break
    if not result:
        for mask in masks:
            contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            for c in sorted(contours,key=cv2.contourArea,reverse=True)[:12]:
                area=cv2.contourArea(c)
                if not (.08<area/(ww*hh)<.78):continue
                rect=cv2.minAreaRect(c)
                rw,rh=rect[1]
                if min(rw,rh)<45:continue
                ratio=min(rw,rh)/max(rw,rh)
                if not (.55<ratio<.79):continue
                hull=cv2.convexHull(c)
                if area/max(1,cv2.contourArea(hull))<.72:continue
                result.append(_order(cv2.boxPoints(rect))/factor)
                break
            if result:break
    return result
def _signature(img):
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    gray=cv2.GaussianBlur(gray,(3,3),0)
    gray=cv2.createCLAHE(clipLimit=1.7,tileGridSize=(5,7)).apply(gray)
    small=cv2.resize(gray,(120,168),interpolation=cv2.INTER_AREA).astype(np.float32)
    dx=cv2.Sobel(small,cv2.CV_32F,1,0,ksize=3)
    dy=cv2.Sobel(small,cv2.CV_32F,0,1,ksize=3)
    grad=cv2.magnitude(dx,dy)
    grad=cv2.GaussianBlur(grad,(3,3),0)
    grad=(grad-grad.mean())/(grad.std()+1e-4)
    tone=(small-small.mean())/(small.std()+1e-4)
    lab=cv2.cvtColor(cv2.resize(img,(120,168)),cv2.COLOR_BGR2LAB).astype(np.float32)
    ab=(lab[:,:,1:]-128)/45.
    return grad,tone,ab
@lru_cache(maxsize=1)
def _refs():
    refs=[]
    for p in sorted((ROOT/'static/cards').glob('*.jpg')):
        raw=cv2.imread(str(p))
        if raw is None:continue
        resized=cv2.resize(raw,(W,H),interpolation=cv2.INTER_AREA)
        refs.append((p.stem,_signature(resized)))
    if len(refs)!=52:raise RuntimeError(f'Expected 52 cards, got {len(refs)}')
    return refs
def _score(a,b):
    return float((a[0]*b[0]).mean()*.48+(a[1]*b[1]).mean()*.39+(a[2]*b[2]).mean()*.13)
def _recognize(crop):
    results=[]
    for oriented in (crop,cv2.rotate(crop,cv2.ROTATE_180),
                     cv2.flip(crop,1),cv2.flip(cv2.rotate(crop,cv2.ROTATE_180),1)):
        sig=_signature(oriented)
        results.extend([(_score(sig,ref),name,oriented) for name,ref in _refs()])
    results.sort(key=lambda x:x[0],reverse=True)
    return results
def _preview(img):
    small=cv2.resize(img,(180,252),interpolation=cv2.INTER_AREA)
    ok,buf=cv2.imencode('.jpg',small,[cv2.IMWRITE_JPEG_QUALITY,75])
    return ('data:image/jpeg;base64,'+base64.b64encode(buf).decode()) if ok else None
def detect_guided_card(frame):
    if frame is None or frame.size==0:return {'ok':False,'message':'No photo was captured'}
    q=_quads(frame)
    if not q:
        return {'ok':False,'message':'No complete rectangular card found. Keep all four card edges visible on the table.', 'detected':False}
    all_candidates=[]
    for quad in q:
        crop=_warp(frame,quad)
        ranks=_recognize(crop)
        best=ranks[0]
        runner=next((r for r in ranks if r[1]!=best[1]),ranks[1])
        all_candidates.append((best[0],best,runner,quad))
    all_candidates.sort(key=lambda x:x[0],reverse=True)
    score,best,runner,quad=all_candidates[0]
    name=best[1]
    margin=score-runner[0]
    candidate={'detected':True,'preview':_preview(best[2]),'score':round(score,3),'margin':round(margin,3),'bestGuess':name,'alternatives':[r[1] for r in _recognize(best[2])[:5]]}
    if score<.27 or margin<.035:
        return {'ok':False,'message':f'Card found, but matching is uncertain ({name}, score {score:.2f}, gap {margin:.2f}). Check the crop below.',**candidate}
    suit,rank=name.split('_',1)
    return {'ok':True,'cardId':name,'label':rank+SUITS[suit],**candidate}
def detect_card(frame):return detect_guided_card(frame)

