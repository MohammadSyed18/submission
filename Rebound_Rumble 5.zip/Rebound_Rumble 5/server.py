from pathlib import Path
import cv2
import numpy as np
from fastapi import FastAPI,Request
from fastapi.responses import FileResponse,JSONResponse
from fastapi.staticfiles import StaticFiles
from scanner import detect_guided_card
ROOT=Path(__file__).resolve().parent
app=FastAPI(title='Rebound Rumble')
app.mount('/static',StaticFiles(directory=str(ROOT/'static')),name='static')
@app.get('/')
def home():return FileResponse(ROOT/'static'/'index.html')
@app.get('/data/cards')
def cards():return FileResponse(ROOT/'data'/'cards.json',media_type='application/json')
@app.post('/api/scan')
async def scan(request:Request):
 data=await request.body()
 if len(data)>2_000_000:return JSONResponse({'ok':False,'message':'Frame too large'},status_code=413)
 image=cv2.imdecode(np.frombuffer(data,np.uint8),cv2.IMREAD_COLOR)
 if image is None:return JSONResponse({'ok':False,'message':'Invalid image'},status_code=400)
 return detect_guided_card(image)

